package cmsc256;

import bridges.connect.Bridges;

import bridges.connect.DataSource;

import bridges.data_src_dependent.Song;

import java.util.Comparator;



public abstract class SongComparator implements Comparator<Song> {


    @Override
    public int compare(Song song1, Song song2) {
        return song1.getAlbumTitle().compareTo(song2.getAlbumTitle());
    }


}








