package cmsc256;

import bridges.connect.Bridges;

import bridges.connect.DataSource;

import bridges.data_src_dependent.Song;
import jdk.nashorn.api.scripting.ScriptObjectMirror;

import java.util.Collections;
import java.util.List;


public class SongList {
    private String getTitle;
    private String getArtist;
    private String getAlbum;


    public static void main(String[] args) {

        Bridges bridges = new Bridges(5, "rizviab", "758109054030");

        DataSource ds = bridges.getDataSource();

        List<Song> songData = null;

        try {

            songData = ds.getSongData();

        } catch (Exception e) {

            System.out.println("Unable to connect to Bridges.");

        }
        int songDataSize = songData.size();

        LList list = new LList();




        for (int i = 0; i < songDataSize; i++) {

            Song entry = songData.get(i);
            list.insert(entry);
            //System.out.println("" + i + "Title: " + entry.getAlbumTitle() + "" + "Artist: " + entry.getArtist() + "" + "Album: " + entry.getAlbumTitle());                 //System.out.println("" + i + ".  " + entry.getArtist() + " was in " + entry.getSongTitle());

        }

        // filter by artist

        // Find out how you can sort that list using the comparator

        // println
    }





    public <T> void getSong() {
    }
}